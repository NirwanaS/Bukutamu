<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/data', 'DataController::index');
$routes->get('/report', 'TamuController::index');

// auth
$routes->get('login', 'AuthController::login');
$routes->post('login', 'AuthController::login');
$routes->get('logout', 'AuthController::logout');

$routes->group('data',['filer'=>'auth'], function($routes){
    $routes->get('','DataController::index');
    $routes->post('','DataController::create');
    $routes->post('edit/(:any)','DataController::edit/$1');
    $routes->get('delete/(:any)','DataController::delete/$1');
});

// $routes->get('data', 'DataController::index', ['filter' => 'auth']);
// $routes->get('report', 'TamuController::index', ['filter' => 'auth']);