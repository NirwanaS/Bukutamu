<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Ini halaman report
<?= $this->endSection() ?>