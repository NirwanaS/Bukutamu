<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link <?php echo (uri_string() == '') ? "" : "collapsed" ?>" href=".">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li><!-- End Dashboard Nav -->

        <?php
        if (session()->get('role')=='admin'){
        ?>
        <li class="nav-item">
            <a class="nav-link <?php echo (uri_string() == 'data') ? "" : "collapsed" ?>" href="data">
                <i class="bi bi-layout-text-window-reverse"></i>
                <span>Data Tamu</span>
            </a>
        </li>
        <?php
        }
        ?>
        <!-- End Data tamu Page Nav -->

        
        <!-- End Report Nav -->

    </ul>

</aside><!-- End Sidebar-->