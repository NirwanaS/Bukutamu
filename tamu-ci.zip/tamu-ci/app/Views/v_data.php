<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<div class="col-12">
                            <div class="card recent-sales overflow-auto">
                                <div class="filter">
                                    <!-- <button type="button" class="btn btn-primary rounded-pill btn-normal" style="margin-right: 10px;">Tambah Data</button> -->
                                    <button type="button" class="btn btn-primary" style="margin-right: 30px;"><i class="bi bi-plus me-1"></i> Tambah Data</button>
                                </div>

                                <div class="card-body">
                                    <h5 class="card-title">Data Tamu <span>| Bulan</span></h5>

                                    <table class="table table-borderless datatable">
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Nama</th>
                                                <th scope="col">Pendidikan</th>
                                                <th scope="col">Pekerjaan</th>
                                                <th scope="col">Usia</th>
                                                <th scope="col">Alamat</th>
                                                <th scope="col">Hp</th>
                                                <th scope="col"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($data as $index => $data): ?>
                                                <tr>
                                                    <th scope="row"><?php echo $index + 1 ?></th>
                                                    <td><?php echo $data['nama'] ?></td>
                                                    <td><?php echo $data['pendidikan'] ?></td>
                                                    <td><?php echo $data['pekerjaan'] ?></td>
                                                    <td><?php echo $data['usia'] ?></td>
                                                    <td><?php echo $data['alamat'] ?></td>
                                                    <td><?php echo $data['hp'] ?></td>
                                                    <td>
                                                        aksi
                                                    </td>
                                                </tr>
                                            <?php endforeach ?>
                                        </tbody>
                                    </table>

                                </div>

                            </div>
                        </div>
                        <!-- End Data Tamu -->

                    </div>
<?= $this->endSection() ?>