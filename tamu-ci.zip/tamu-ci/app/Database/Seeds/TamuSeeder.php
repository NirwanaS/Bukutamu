<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class TamuSeeder extends Seeder
{
    public function run()
    {
        // membuat data
        $data = [
            [
                'nama' => 'Ananabilla Rizky',
                'pendidikan'  => 'S1',
                'pekerjaan' => 'Mahasiswa',
                'keperluan'=> 'pengajuan kegiatan magang',
                'usia' => 21,
                'alamat' => 'Balikpapan',
                'hp' => '08147208792',
                'created_at' => date("Y-m-d H:i:s"),
            ],
            [
                'nama' => 'Alfino Almero S',
                'pendidikan'  => 'S1',
                'pekerjaan' => 'PNS/TNI/POLRI',
                'keperluan'=> 'Menemui pihak Dinkominfo untuk permohonan pembuatan sebuah Web',
                'usia' => 21,
                'alamat' => 'Tegal',
                'hp' => '08140656789',
                'created_at' => date("Y-m-d H:i:s"),
            ],
            [
                'nama' => 'Dimas Panuntun',
                'pendidikan'  => 'S1',
                'pekerjaan' => 'Mahasiswa',
                'keperluan'=> 'pengajuan kegiatan magang',
                'usia' => 21,
                'alamat' => 'Surabaya',
                'hp' => '08123456789',
                'created_at' => date("Y-m-d H:i:s"),
            ]
        ];

        foreach ($data as $item) {
            // insert semua data ke tabel
            $this->db->table('tamu')->insert($item);
        }
    }
}
