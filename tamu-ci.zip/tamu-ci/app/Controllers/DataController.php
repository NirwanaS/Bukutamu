<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\TamuModel;
use CodeIgniter\HTTP\ResponseInterface;

class DataController extends BaseController
{
    protected $data;
    // protected $validation;

    function __construct()
    {
        $this->data = new TamuModel();
    }
    
    public function index()
    {
        $data = $this->data->findAll();
        $datamu['data'] = $data;
        return view('v_data', $datamu);
    }
}
