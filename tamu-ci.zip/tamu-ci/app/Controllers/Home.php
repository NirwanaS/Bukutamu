<?php

namespace App\Controllers;
use App\Models\TamuModel;

class Home extends BaseController
{
    protected $tamu;
    function __construct()
    {
        $this->tamu = new TamuModel();
    }
    public function index(): string
    {
        $tamu = $this->tamu->findAll();
        $data['tamu']=$tamu;
        
        return view('v_home', $data);
    }
}
