<?php
function userLogin()
{
    $db = \Config\Database::connect();
    return $db->table('$tables')->countAllResults();
}
function countData($tables)
{
    $db = \Config\Database::connect();
    return $db->table($tables)->countAllResults();
}
?>